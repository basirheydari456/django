from django.db import models

from shop_product.models import Product


class Tag(models.Model):
    title = models.CharField(max_length=50, verbose_name='عنوان')
    name = models.CharField(max_length=50, verbose_name='عنوان در url')
    product = models.ManyToManyField(Product,verbose_name='محصول' ,blank=True)

    class Meta:
        verbose_name_plural = 'برچب ها'
        verbose_name = 'برچسب'

    def __str__(self):
        return self.title
