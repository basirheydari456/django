from django.apps import AppConfig


class ShopTagConfig(AppConfig):
    name = 'shop_tag'
    verbose_name = 'ماژول برچسب'
