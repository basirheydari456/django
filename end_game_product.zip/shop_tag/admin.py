from django.contrib import admin

from shop_tag.models import Tag

admin.site.register(Tag)
