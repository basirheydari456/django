from django.contrib import admin

admin.site.index_template = 'admin/app_index.html'
admin.autodiscover()
