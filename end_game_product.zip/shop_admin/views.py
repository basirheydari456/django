from functools import wraps

from django.shortcuts import render, redirect


def admin_view(views,cacheable=False):
    @wraps(views)
    def inner_decorator(request,*args,**kwargs):
        if not request.user.is_superuser and not request.user.is_staff:
            return redirect('/account')
        return views(request,*args,**kwargs)
    return inner_decorator
