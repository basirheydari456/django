from django.apps import AppConfig



class ShopAdminConfig(AppConfig):
    name = 'shop_admin'
