from django.contrib.auth.models import User
from django.db import models

# from shop_accounts.models import Account
from shop_product.models import Product
from datetime import datetime

from shopp_account.models import Avatar


class Comments(models.Model):
    message = models.TextField(blank=True,null=True,verbose_name='نظر')
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='کاربر', default='1',null=True,blank=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, verbose_name='نظر', default='1',null=True,blank=True)
    product = models.ForeignKey(Product,on_delete=models.CASCADE,verbose_name='محصول', default='1',null=True,blank=True)
    active = models.BooleanField(default=False,verbose_name='تایید کامنت')
    date = models.DateTimeField(auto_now_add=True, verbose_name='اتاریخ ثبت کامنت')
    avatar = models.ForeignKey(Avatar,on_delete=models.CASCADE,verbose_name='آواتار کاربر', default='1',null=True,blank=True)


    class Meta:
        verbose_name_plural = 'نظرات'
        verbose_name = 'نظر'
        ordering = ['-date']

    def children(self):
        return Comments.objects.filter(parent=self)

    def __str__(self):
        return self.message
