
from django.urls import path

from .views import comment_view,delete_comment,confirm_comment



urlpatterns = [
    path('comment/<product_id>', comment_view),
    path('remove-comment/<product_id>/<comment_detail>', delete_comment),
    path('confirm-comment/<product_id>/<comment_detail>', confirm_comment),
]
