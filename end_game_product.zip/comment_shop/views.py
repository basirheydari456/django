import sweetify
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.shortcuts import render, redirect

from comment_shop.forms import CommentForm
from comment_shop.models import Comments
from shop_product.models import Product


# CommentView
from shopp_account.models import Avatar



@login_required(login_url='/login')
def comment_view(request,*args,**kwargs):
    global product_id
    product_id = kwargs.get('product_id')
    comment_form = CommentForm(request.POST or None)
    if comment_form.is_valid():
        parent_obj = None
        message = comment_form.cleaned_data.get('message')
        parent_id = request.POST.get('parent_id')
        if parent_id is not None:
            parent_qs = Comments.objects.filter(id=parent_id)
            if parent_qs.exists() and parent_qs.count() == 1:
                parent_obj = parent_qs.first()

        qw = Avatar.objects.filter(user_id=request.user.id).first()

        Comments.objects.get_or_create(message=message, parent=parent_obj, product_id=product_id,
                                       user_id=request.user.id, avatar_id=qw.id)
        sweetify.success(request, 'عملیات موفق', icon='success', text='نظر شما با موقیت ارسال شد', persistent='باشه')

        product = Product.objects.get_by_id(product_id)

        return redirect(f'/products/{product.id}/{product.title.replace(" ", "-")}')


# CommentDelete
@login_required(login_url='/login')
def delete_comment(request, *args, **kwargs):
    product_id = kwargs.get('product_id')
    comment_detail = kwargs.get('comment_detail')
    if comment_detail is not None:
        comment = Comments.objects.filter(id=comment_detail, user_id=request.user.id)
        if comment is not None:
            comment.delete()
            sweetify.success(request, 'عملیات موفق', icon='success', text='نظر شما با موقیت حذف شد', persistent='باشه')
        if request.user.is_superuser:
            comment = Comments.objects.filter(id=comment_detail)
            comment.delete()

    product = Product.objects.get_by_id(product_id)


    return redirect(f'/products/{product.id}/{product.title.replace(" ", "-")}')


# CommentConfirm
def confirm_comment(request, *args, **kwargs):
    if not request.user.is_superuser:
        return redirect('/')
    product_id = kwargs.get('product_id')
    comment_detail = kwargs.get('comment_detail')
    if request.user.is_superuser:
        if comment_detail is not None:
            comment = Comments.objects.filter(id=comment_detail)
            if comment is not None:
                for pr in comment:
                    pr.active = True
                    pr.save()
    product = Product.objects.get_by_id(product_id)

    return redirect(f'/products/{product.id}/{product.title.replace(" ", "-")}')
