from django.contrib import admin

from .models import Comments

class CommentAdminManager(admin.ModelAdmin):
    list_display = ['__str__', 'product','active','user']
    list_editable = ['active']



admin.site.register(Comments,CommentAdminManager)
