from django.apps import AppConfig


class ShopCommentisConfig(AppConfig):
    name = 'comment_shop'
    verbose_name = 'ماژول نظرات'

