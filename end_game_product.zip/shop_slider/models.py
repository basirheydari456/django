import os
from random import randint

from django.db import models


def upload_image_path(filepath):
    base_name = os.path.basename(filepath)
    name, ext = os.path.splitext(base_name)
    return name, ext


def upload_image_slider(instance, filename):
    name, ext = upload_image_path(filename)
    new_name = randint(1, 1234567890)
    final_name = f'{new_name}{ext}'
    return f'products/slider/{final_name}'


class Slider(models.Model):
    title = models.CharField(max_length=50,verbose_name='عنوان')
    image = models.ImageField(upload_to=upload_image_slider, null=True, blank=True, verbose_name='تصویر')

    class Meta:
        verbose_name_plural = 'تصاویر'
        verbose_name = 'تصویر'

    def __str__(self):
        return self.title
