from django.contrib import admin

from shop_slider.models import Slider

admin.site.register(Slider)
