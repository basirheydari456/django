from django.apps import AppConfig


class ShopSliderConfig(AppConfig):
    name = 'shop_slider'
    verbose_name = 'ماژول اسلایدر'
