from django.contrib import admin

from shop_category.models import Category, ChildCategory

admin.site.register(Category)
admin.site.register(ChildCategory)

