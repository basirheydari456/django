from django.db import models

from shop_product.models import Product


class Category(models.Model):
    title = models.CharField(max_length=50,verbose_name='عنوان')
    name = models.CharField(max_length=50,verbose_name='عنوان در url')
    products = models.ManyToManyField(Product,null=True,blank=True,verbose_name='حصول')

    class Meta:
        verbose_name_plural = 'دسته بندی ها'
        verbose_name = 'دسته بندی'

    def __str__(self):
        return self.title


class ChildCategory(models.Model):
    title = models.CharField(max_length=50,verbose_name='عنوان')
    name = models.CharField(max_length=50,verbose_name='عنوان در url')
    category = models.ForeignKey(Category,on_delete=models.CASCADE,default='1',null=True,blank=True,verbose_name='دسته بندی')
    products = models.ManyToManyField(Product,null=True,blank=True,verbose_name='حصول')

    class Meta:
        verbose_name_plural = 'جزییات دسته بندی ها'
        verbose_name = 'جزییات دسته بندی'

    def __str__(self):
        return self.title