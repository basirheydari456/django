from django.apps import AppConfig


class ShopCategoryConfig(AppConfig):
    name = 'shop_category'
    verbose_name = 'ماژول دسته بندی'

