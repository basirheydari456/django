from django.contrib.auth.models import User
from django.db import models

from shop_product.models import Product, Color


class Order(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='کاربر')
    payment_date = models.DateTimeField(auto_now_add=True, verbose_name='اریخ پرداخت')
    is_paid = models.BooleanField(default=False, verbose_name='پرداخت شده')

    class Meta:
        verbose_name_plural = 'سبد های خرید'
        verbose_name = 'سبد خرید'

    # Get Total Price
    def get_total_price(self):
        amount = 0
        for detail in self.orderdetail_set.all():
            amount += detail.count * detail.price
        return amount

    # Get Total Discount Percent
    def get_total_discount_percent(self):
        product = self.orderdetail_set.all()
        total = 0
        for discount in product:
            total += discount.product.discount / product.count()
        return round(total)

    # Get Total Discount Price
    def get_total_discount_price(self):
        discount = self.get_total_discount_percent() * self.get_total_price() // 100
        total_discount = self.get_total_price() - discount
        return total_discount

    def __str__(self):
        return self.owner.username


class OrderDetail(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, verbose_name='سبد خرید')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='محصول')
    price = models.IntegerField(verbose_name='قیمت')
    count = models.IntegerField(verbose_name='تعداد')
    color = models.ForeignKey(Color, default=1, on_delete=models.CASCADE, verbose_name='رنگ')

    class Meta:
        verbose_name_plural = 'جزییات سبد های خرید'
        verbose_name = 'جزییات سبد خرید'

    def __str__(self):
        return self.product.title
