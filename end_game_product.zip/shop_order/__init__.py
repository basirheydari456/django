default_app_config = 'shop_order.apps.ShopOrderConfig'
