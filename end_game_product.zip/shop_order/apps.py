from django.apps import AppConfig


class ShopOrderConfig(AppConfig):
    name = 'shop_order'
    verbose_name = 'ماژول سبد خرید'
