from django.contrib import admin

from shop_order.models import OrderDetail, Order

admin.site.register(Order)
admin.site.register(OrderDetail)
