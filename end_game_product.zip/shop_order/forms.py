from django import forms
from shop_order.models import OrderDetail
from shop_product.models import Product


class OrderForm(forms.ModelForm):
    product_id = forms.IntegerField(widget=forms.HiddenInput())

    class Meta():
        model = OrderDetail
        fields = ("count","color")
        widgets = {
            "count": forms.NumberInput(attrs={'class': 'count'}),
            "color": forms.RadioSelect(attrs={'checked':'checked'})
        }

    # Filter (color field) by Product
    def __init__(self, *args, **kwargs):
        global colors
        super(OrderForm, self).__init__(*args, **kwargs)
        initial = kwargs.get('initial')
        product_id = initial.get('product_id')
        product = Product.objects.filter(id=product_id)
        for pr in product:
            colors = pr.color.all()
        self.fields['color'].queryset = colors
