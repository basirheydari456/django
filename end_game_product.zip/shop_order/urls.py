from django.urls import path


from .views import add_user_order,open_user_order,delete_order,edit_order

urlpatterns = [
    path('add_user_order', add_user_order , name='add_user_order'),
    path('open_user_order', open_user_order , name='open_user_order'),
    path('order/<order_detail>', delete_order , name='delete_order'),
    path('edit-order/<order_detail>', edit_order , name='edit_order'),
]