from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.generic import CreateView
import sweetify

from shop_order.forms import OrderForm
from shop_order.models import Order, OrderDetail
from shop_product.models import Product


@login_required(login_url='/login')
def add_user_order(request):
    product_id = request.POST.get('product_id')
    new_order_form = OrderForm(request.POST,initial={'product_id':product_id})

    if request.method == 'POST':
        if new_order_form.is_valid():
            order = Order.objects.filter(owner_id=request.user.id, is_paid=False).first()
            if order is None:
                order = Order.objects.create(owner_id=request.user.id, is_paid=False)

            product_id = new_order_form.cleaned_data.get('product_id')
            count = new_order_form.cleaned_data.get('count')
            color = new_order_form.cleaned_data.get('color')
            print(new_order_form.cleaned_data)
            print(new_order_form)

            product: Product = Product.objects.get_by_id(product_id)

            order_detail_exists = order.orderdetail_set.filter(product_id=product_id,order__owner_id=request.user.id)
            if order_detail_exists.exists():
                sweetify.warning(request, 'عملیات ناموفق', icon='warning', text='این محصول قبلا به سبد خرید اضافه شده',
                                 persistent='باشه')
                return redirect(f'products/{product.id}/{product.title.replace(" ", "-")}')
            else:
                sweetify.success(request, 'عملیات موفق', icon='success', text='محصول شما به سبد خرید اضافه شد',
                                 persistent='باشه')
                order.orderdetail_set.create(product_id=product.id, count=count, price=product.price, color=color)

            return redirect(f'products/{product.id}/{product.title.replace(" ", "-")}')


@login_required(login_url='/login')
def open_user_order(request):
    context = {
        'order': None,
        'order_detail': None,
        'get_total_price': 0,
        'get_total_discount_price':0,
        'get_total_discount_percent':0
    }
    open_order: Order = Order.objects.filter(owner_id=request.user.id, is_paid=False).first()
    if open_order is not None:
        context['order'] = open_order
        context['order_detail'] = open_order.orderdetail_set.all()
        context['get_total_price'] = open_order.get_total_price()
        context['get_total_discount_price'] = open_order.get_total_discount_price()
        context['get_total_discount_percent'] = open_order.get_total_discount_percent()

    return render(request, 'order/open_order_page.html', context)


@login_required(login_url='/login')
def delete_order(request, *args, **kwargs):
    order_detail = kwargs.get('order_detail')
    if order_detail is not None:
        order = OrderDetail.objects.filter(id=order_detail, order__owner_id=request.user.id)
        if order is not None:
            order.delete()
            sweetify.success(request, 'عملیات موفق', icon='success', text='محصول شما با موفقیت حذف شد',persistent='باشه')

    return redirect('/open_user_order')


@login_required(login_url='/login')
def edit_order(request,*args,**kwargs):
    order_count = request.POST.get('order-count')
    order_detail = kwargs.get('order_detail')
    if order_detail is not None:
        order = OrderDetail.objects.filter(id=order_detail,order__owner_id=request.user.id)
        if order is not None:
            for count in order:
                if count is not None:
                    count.count = order_count
                    count.save()
                sweetify.success(request, 'عملیات موفق', icon='success', text='محصول شما بروزرسانی شد',
                                     persistent='باشه')
                return redirect('/open_user_order')


