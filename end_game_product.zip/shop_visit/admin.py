from django.contrib import admin

from shop_visit.models import Visit

class VisitAdminManager(admin.ModelAdmin):
    list_display = ['__str__','product']
    search_fields = ['user_ip']

    class Meta:
        model= Visit

admin.site.register(Visit,VisitAdminManager)

