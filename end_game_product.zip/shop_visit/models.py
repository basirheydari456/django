from django.db import models

from shop_product.models import Product


class Visit(models.Model):
    user_ip = models.TextField(default=None,verbose_name='آی پی کاربر')
    product = models.ForeignKey(Product,default='',on_delete=models.CASCADE,verbose_name='محصول',blank=True,null=True)


    class Meta:
        verbose_name_plural = 'آی پی ها'
        verbose_name = 'آی پی'


    def __str__(self):
        return self.user_ip

