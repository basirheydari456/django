from django.apps import AppConfig


class ShopVisitConfig(AppConfig):
    name = 'shop_visit'
    verbose_name = 'ماژول آی پی'
