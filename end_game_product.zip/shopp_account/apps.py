from django.apps import AppConfig


class ShopAccountConfig(AppConfig):
    name = 'shopp_account'
    verbose_name = 'ماژول اکانت'
