from django import forms
from django.contrib.auth.models import User
from django.core import validators

from shopp_account.models import Avatar


class LoginForm(forms.Form):
    username = forms.CharField(
        required=False,
        label='نام کاربری',
        widget=forms.TextInput({'class': 'form-input', 'placeholder': 'نام کاربری'}))
    password = forms.CharField(
        required=False,
        label='کلمه عبور',
        widget=forms.PasswordInput({'class': 'form-input', 'placeholder': 'کلمه عبور'}))

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if username == '':
            raise forms.ValidationError('فیلد ایمیل را پر کنید')
        return username

    def clean_password(self):
        password = self.cleaned_data.get('password')
        if password == '':
            raise forms.ValidationError('فیلد کلمه عبور را پر کنید')
        return password


class RegisterForm(forms.Form):
    email = forms.CharField(
        required=False,
        validators=[validators.EmailValidator('ایمیل وارد شده معتبر نمیباشد')],
        label='ایمیل',
        widget=forms.TextInput({'class': 'form-input', 'placeholder': 'ایمیل'}))
    username = forms.CharField(
        required=False,
        label='نام کاربری',
        widget=forms.TextInput({'class': 'form-input', 'placeholder': 'نام کاربری'}))
    password = forms.CharField(
        required=False,
        label='کلمه عبور',
        widget=forms.PasswordInput({'class': 'form-input', 'placeholder': 'رمز عبور'}))
    password2 = forms.CharField(
        required=False,
        label='کلمه عبور مجدد',
        validators=[validators.MinLengthValidator(5, 'بیش از 5 کاراکتر')],
        widget=forms.PasswordInput(
            {'class': 'form-input', 'placeholder': 'رمز عبور مجدد'}))

    def clean_email(self):
        email = self.cleaned_data.get('email')
        qs = User.objects.filter(email=email).exists()
        if email == '':
            raise forms.ValidationError('فیلد ایمیل را پر کنید')
        elif qs:
            raise forms.ValidationError('کاربری با این نام ایمیل وجود دارد')
        return email


    def clean_username(self):
        username = self.cleaned_data.get('username')
        qs = User.objects.filter(username=username).exists()
        if username == '':
            raise forms.ValidationError('فیلد نام کاربری را پر کنید')
        elif qs:
            raise forms.ValidationError('کاربری با این نام کاربری وجود دارد')
        return username

    def clean_password2(self):
        password = self.cleaned_data.get('password')
        password2 = self.cleaned_data.get('password2')
        if password == '' or password2 == '':
            raise forms.ValidationError('فیلد نام رمز عبور را پر کنید')
        if password != password2:
            raise forms.ValidationError('رمز عبور برابر نیست')
        return password2


class EditForm(forms.Form):
    email = forms.CharField(
        required=False,
        validators=[validators.EmailValidator('ایمیل وارد شده معتبر نمیباشد')],
        label='ایمیل',
        widget=forms.TextInput({'class': 'form-input', 'placeholder': 'ایمیل'}))
    username = forms.CharField(
        required=False,
        label='نام کاربری',
        widget=forms.TextInput({'class': 'form-input', 'placeholder': 'نام کاربری'}))

    def clean_email(self):
        email = self.cleaned_data.get('email')
        qs = User.objects.filter(email=email)
        if qs.exists():
            raise forms.ValidationError('ایمیل موجود است')
        return email

    def clean_username(self):
        username = self.cleaned_data.get('username')
        qs = User.objects.filter(username=username)
        if qs.exists():
            raise forms.ValidationError('نام کاربری موجود است')
        return username


class EditPassword(forms.Form):
    old_password = forms.CharField(
        required=False,
        label='نام کاربری',
        widget=forms.PasswordInput({'class': 'form-input', 'placeholder': 'رمز فعلی'}))
    new_password = forms.CharField(
        required=False,
        label='نام کاربری',
        widget=forms.PasswordInput({'class': 'form-input', 'placeholder': 'رمز جدید'}))
    new_password2 = forms.CharField(
        required=False,
        label='نام کاربری',
        validators=[validators.MinLengthValidator(5, 'باید بیش از 5 کاراکتر باشد')],
        widget=forms.PasswordInput({'class': 'form-input', 'placeholder': 'رمز جدید مجدد'}))


class EditAvatar(forms.Form):
    image = forms.ImageField(required=False, label='', widget=forms.FileInput(attrs={'class': 'change-image-inp'}))

# class EditAvatar(forms.ModelForm):
#     class Meta:
#         model = Avatar
#         fields = ('image',)
#         widgets = {forms.ImageField,attrs=}
