import os
from random import randint

from django.contrib.auth.models import User
from django.db import models

from shop_product.models import Product


def upload_image_path(filepath):
    base_name = os.path.basename(filepath)
    name, ext = os.path.splitext(base_name)
    return name, ext


def upload_image_profile(instance, filename):
    name, ext = upload_image_path(filename)
    new_name = randint(1, 1234567890)
    final_name = f'{new_name}{ext}'
    return f'accounts/{final_name}'


class Avatar(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default='1', verbose_name='کاربر')
    image = models.ImageField(upload_to=upload_image_profile, default='accounts/837113388.jpg', verbose_name='آواتار')

    class Meta:
        verbose_name_plural = 'آواتار کاربر ها'
        verbose_name = 'آواتار'
        ordering = ['-id']

    def __str__(self):
        return self.user.username


class Favorites(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, default='', verbose_name='کاربر')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, default='', verbose_name='محصول')

    class Meta:
        verbose_name_plural = 'علاقه مندی ها'
        verbose_name = 'علاقه مندی'

    def __str__(self):
        return self.product.title
