from django.urls import path
from .views import \
    register_user,login_user,logout_user,user_account_main_page,user_sidebar,user_edit_profile,user_edit_password,user_edit_avatar

from django.contrib.auth import views as auth_views

urlpatterns = [
    path('register', register_user,name='register'),
    path('login', login_user,name='login'),
    path('logout', logout_user,name='logout'),
    path('account', user_account_main_page,name='user_account_main_page'),
    path('user-sidebar', user_sidebar,name='user_sidebar'),
    path('account/edit', user_edit_profile,name='user_edit_profile'),
    path('account/edit-password', user_edit_password,name='user_edit_password'),
    path('account/edit-avatar', user_edit_avatar,name='user_edit_avatar'),
    path("reset_password/", auth_views.PasswordResetView.as_view(), name="password_reset"),

    path("reset_password_sent/", auth_views.PasswordResetDoneView.as_view(), name="password_reset_done"),

    path("reset/<uidb64>/<token>", auth_views.PasswordResetConfirmView.as_view(), name="password_reset_confirm"),

    path("reset_password_complete/", auth_views.PasswordResetCompleteView.as_view(), name="password_reset_complete")
]