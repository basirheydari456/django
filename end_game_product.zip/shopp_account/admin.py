from django.contrib import admin

from shopp_account.models import Avatar, Favorites

admin.site.register(Avatar)
admin.site.register(Favorites)
