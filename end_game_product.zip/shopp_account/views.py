from django.contrib.auth import logout, authenticate, login, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
import sweetify

from shopp_account.forms import LoginForm, RegisterForm, EditForm, EditPassword, EditAvatar
from shopp_account.models import Favorites, Avatar

from shop_product.models import Product
from shop_product.views import product_detail_view


def login_user(request):
    if request.user.is_authenticated:
        return redirect('/')
    login_form = LoginForm(request.POST or None)
    context = {
        'login_form': login_form
    }
    if login_form.is_valid():
        print(login_form.cleaned_data)
        username = login_form.cleaned_data.get('username')
        password = login_form.cleaned_data.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            print(f'{username}logged user is success')
            return redirect('/')
        else:
            login_form.add_error('username', 'کاربری با این مشخصات یافت نشد')
            print('error logged')

    return render(request, 'account/login.html', context)


def register_user(request):
    if request.user.is_authenticated:
        return redirect('/')
    register_form = RegisterForm(request.POST or None)
    context = {
        'register_form': register_form
    }
    if register_form.is_valid():
        print(register_form.cleaned_data)
        email = register_form.cleaned_data.get('email')
        username = register_form.cleaned_data.get('username')
        password = register_form.cleaned_data.get('password')
        new_user = User.objects.create_user(email=email, username=username, password=password)
        user = authenticate(request, email=email, username=username, password=password)
        if user is not None:
            login(request, user)
            user_avatar = Avatar.objects.create(user_id=request.user.id, image='accounts/795424268.jpg')
            print(f'{username}logged user is success')
            return redirect('/')
        print(f'register is success {new_user}')

    return render(request, 'account/register.html', context)


def logout_user(request):
    logout(request)
    return redirect('/')


@login_required(login_url='/login')
def user_account_main_page(request):
    user_id = request.user.id
    user = User.objects.get(id=user_id)


    favorite_products = Favorites.objects.filter(product__favorite=True, user_id=request.user.id)


    return render(request, 'account/user_account_main_page.html',
                  {'user': user, 'favorite_products': favorite_products})


@login_required(login_url='/login')
def user_edit_profile(request):
    user_id = request.user.id
    user = User.objects.get(id=user_id)
    edit_form = EditForm(request.POST or None)
    context = {
        'edit_form': edit_form
    }
    if edit_form.is_valid():
        username = edit_form.cleaned_data.get('username')
        email = edit_form.cleaned_data.get('email')
        if username == '':
            user.username = user.username
        else:
            user.username = username
        if email == '':
            user.email = user.email
        else:
            user.email = email
        user.save()
        sweetify.success(request, 'عملیات موفق', icon='success', text='اطلاعات شما با موفقیت ویرایش شد',
                         persistent='باشه')
        return redirect('/account')
    # context['edit_form'] = EditForm()

    return render(request, 'account/user_edit_profile.html', context)


@login_required(login_url='/login')
def user_edit_password(request):
    edit_password_form = EditPassword(request.POST or None)
    user_id = request.user.id
    user = User.objects.get(id=user_id)
    context = {
        'edit_password_form': edit_password_form
    }
    if edit_password_form.is_valid():
        old_password = edit_password_form.cleaned_data.get('old_password')
        new_password = edit_password_form.cleaned_data.get('new_password')
        new_password2 = edit_password_form.cleaned_data.get('new_password2')

        if old_password == '':
            edit_password_form.add_error('old_password', 'فیلد رمز عبور را پر کنید')

        elif user.check_password(old_password) == False:
            edit_password_form.add_error('old_password', 'رمز عبور اشتباه است')

        elif new_password == '':
            edit_password_form.add_error('new_password', 'فیلد رمز عبور را پر کنید')

        elif new_password2 == '':
            edit_password_form.add_error('new_password2', 'فیلد رمز عبور را پر کنید')

        elif new_password != new_password2:
            edit_password_form.add_error('new_password2', 'رمز عبور برابر نیست')

        else:
            user.set_password(new_password2)
            user.save()
            user = authenticate(request, username=user.username, password=new_password2)
            if user is not None:
                login(request, user)
                sweetify.success(request, 'عملیات موفق', icon='success', text='رمز شما با موفقیت ویرایش شد',
                                 persistent='باشه')
                return redirect('/account')

    return render(request, 'account/user_edit_password.html', context)


@login_required(login_url='/login')
def user_edit_avatar(request):
    edit_user_avatar = EditAvatar(request.POST or None, request.FILES or None)
    user_avatar = Avatar.objects.filter(user_id=request.user.id)
    if request.method == 'POST':
        if edit_user_avatar.is_valid():
            image = edit_user_avatar.cleaned_data.get('image')
            print(image)
            for avatar in user_avatar:
                if image == None:
                    avatar.image = avatar.image
                else:
                    avatar.image = image
                    avatar.save()
        return redirect('/account')


@login_required(login_url='/login')
def user_sidebar(request):
    user_id = request.user.id
    user = User.objects.get(id=user_id)
    user_avatar = Avatar.objects.filter(user_id=request.user.id).first()
    edit_user_avatar = EditAvatar(request.POST or None, request.FILES or None)

    context = {
        'edit_user_avatar': edit_user_avatar,
        'user': user,
        'user_avatar': user_avatar
    }

    return render(request, 'account/user_sidebar.html', context)
