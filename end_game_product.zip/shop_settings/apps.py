from django.apps import AppConfig


class ShopSettingsConfig(AppConfig):
    name = 'shop_settings'
    verbose_name = 'ماژول تنضیمات'
