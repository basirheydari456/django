from django.contrib import admin

from shop_settings.models import ShopSetting

admin.site.register(ShopSetting)
