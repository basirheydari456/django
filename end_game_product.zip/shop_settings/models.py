import os

from django.db import models
from random import randint

from django.db.models.signals import pre_save


def get_image_path(filepath):
    base_name = os.path.basename(filepath)
    name, ext = os.path.splitext(base_name)
    return name, ext


def upload_image_file(instance, filename):
    name, ext = get_image_path(filename)
    new_name = randint(0, 123456789)
    final_name = f'{new_name}{ext}'
    return f'settings/{final_name}'


class ShopSetting(models.Model):
    error_image = models.ImageField(upload_to=upload_image_file, null=True, blank=True)
    slug = models.SlugField(null=True, blank=True)

    class Meta:
        verbose_name_plural = 'تنضیمات'
        verbose_name = 'تنظیم'

    def __str__(self):
        return self.slug


def shop_settings_save_receiver(instance, sender, *args, **kwargs):
    if not instance.slug:
        instance.slug = instance.error_image


pre_save.connect(shop_settings_save_receiver, sender=ShopSetting)
