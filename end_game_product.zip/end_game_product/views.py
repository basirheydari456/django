from django.http import JsonResponse
from django.shortcuts import render, redirect

from shop_category.models import Category
from shop_order.models import Order
from shop_product.Utils import my_grouper, get_ip

from shop_product.models import Product
from shop_settings.models import ShopSetting
from shop_slider.models import Slider


def header(request):
    global count_order
    categories = Category.objects.all()
    order = Order.objects.filter(owner_id=request.user.id).first()


    context = {
        'categories':categories,
        'order':order
    }

    return render(request, 'shared/Header.html', context)


def footer(request):
    context = {}
    return render(request, 'shared/Footer.html', context)


def home_page(request):
    new_product = Product.objects.get_active()[:8]
    new_product_groper = list(my_grouper(8, new_product))

    discount_product = Product.objects.filter(category__name__iexact='amazing-discount')[:8]
    discount_product_groper = list(my_grouper(8, discount_product))

    mobile_product = Product.objects.filter(childcategory__name__exact='mobile')[:8]
    mobile_product_groper = list(my_grouper(8, mobile_product))

    laptop_product = Product.objects.filter(childcategory__name__exact='laptop')[:8]
    laptop_product_groper = list(my_grouper(8, laptop_product))

    must_visit_product = Product.objects.order_by('-visit_count')
    must_visit_product_groper = list(my_grouper(8, must_visit_product))

    user_ip = get_ip(request)
    already_visit_product= Product.objects.filter(visit__user_ip__iexact=user_ip)
    already_visit_product_groper = list(my_grouper(8,already_visit_product))[:8]

    slider = Slider.objects.all()
    context = {
        'slider':slider,
        'new_product_groper': new_product_groper,
        'discount_product_groper': discount_product_groper,
        'mobile_product_groper': mobile_product_groper,
        'laptop_product_groper': laptop_product_groper,
        'must_visit_product_groper':must_visit_product_groper,
        'already_visit_product_groper':already_visit_product_groper
    }
    return render(request, 'index.html', context)


def handler404(request,*args,**kwargs):
    settings = ShopSetting.objects.first()
    print(settings.error_image.url)
    return render(request, '404.html',{'settings':settings})


def autocomplete(request):
    if 'term' in request.GET:
        qs = Product.objects.filter(title__icontains=request.GET.get('term'))
        # print(qs)
        titles = list()
        for product in qs:
            titles.append(product.title)
        # titles = [product.title for product in qs]
        return JsonResponse(titles, safe=False)
    return render(request, 'shared/Header.html')

