from django.conf.urls import url
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include
from django.views.static import serve

from shop_admin.views import admin_view
from .views import home_page, autocomplete,handler404

from end_game_product import settings

admin.site.admin_view = admin_view

urlpatterns = [
    path('', home_page),
    path('', include('shopp_account.urls')),
    path('', include('shop_product.urls')),
    path('', include('shop_order.urls')),
    path('', include('comment_shop.urls')),

    path('admin/', admin.site.urls),
    path('autocomplete/', autocomplete, name='autocomplete'),
    path('$',handler404,name='home'),
    url(r'^media/(?P<path>.*)$', serve,{'document_root': settings.MEDIA_ROOT}),
    url(r'^static/(?P<path>.*)$', serve,{'document_root': settings.STATIC_ROOT}),

]


# # if settings.DEBUG:
# # add root static files
# urlpatterns = urlpatterns + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
# # add media static files
# urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)