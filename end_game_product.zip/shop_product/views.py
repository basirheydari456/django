from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import Http404, HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.views.generic import ListView

from shopp_account.models import Favorites, Avatar
from shop_category.models import Category
from comment_shop.forms import CommentForm
from comment_shop.models import Comments
from shop_order.forms import OrderForm
from shop_product.models import Product, ProductGallery
from shop_visit.models import Visit
from .Utils import my_grouper, get_ip

import sweetify


class ProductListView(ListView):
    template_name = 'products/product_list_page.html'
    context_object_name = 'products'
    paginate_by = 3

    def get_queryset(self):
        return Product.objects.get_active()


class ProductSearchListView(ListView):
    template_name = 'products/product_list_page.html'
    context_object_name = 'products'
    paginate_by = 3

    def get_queryset(self):
        request = self.request
        query = request.GET.get('q')
        if query is not None:
            return Product.objects.search(query)
        return Product.objects.all()


class ProductCategoryList(ListView):
    template_name = 'products/product_list_page.html'
    context_object_name = 'products'
    paginate_by = 3

    def get_queryset(self, *args, **kwargs):
        request = self.request
        categories = request.GET.get('categories')
        if categories is not None:
            return Product.objects.get_by_category(categories)
        return Product.objects.get_active()


# class ProductChildCategoryList(ListView):
#     template_name = 'products/product_list_page.html'
#     context_object_name = 'products'
#     paginate_by = 3
#     def get_queryset(self, *args, **kwargs):
#         request = self.request
#         childcategories = request.GET.get('childcategories')
#         if childcategories is not None:
#             return Product.objects.get_by_child_category(childcategories)
#         return Product.objects.get_active()

def product_detail_view(request, *args, **kwargs):
    global product_id, product, page_obj, comments, comments_count

    # ProductById
    product_id = kwargs.get('product_id')
    product = Product.objects.get_by_id(product_id)
    if product is None:
        raise Http404('نیست')

    # Order
    new_order_form = OrderForm(request.POST or None, initial={'product_id': product_id})

    # Comment
    comment_form = CommentForm(request.POST or None)
    all_comments = Comments.objects.all()
    for pr in all_comments:
        if request.user.is_superuser and request.user.id == pr.user.id:
            pr.active = True
            pr.save()
            comments = Comments.objects.filter(product_id=product_id, parent=None)
        else:
            comments = Comments.objects.filter(product_id=product_id, parent=None)

    comments_count = Comments.objects.filter(product_id=product_id, active=True).count()

    paginator = Paginator(comments, 30)  # Show 25 contacts per page.
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Tag & Category
    category_related = product.childcategory_set.all().first()
    tag_related = product.tag_set.all()

    # Ip Count
    user_ip = get_ip(request)
    u = Visit(user_ip=user_ip, product_id=product_id)
    result = Visit.objects.filter(user_ip__iexact=user_ip, product_id=product_id)
    if len(result) == 1:
        print('ip exists')
    elif len(result) > 1:
        print('ip exits more...')
    else:
        u.save()
        print('ip is unique')
        product.visit_count += 1
        product.save()
    visit_count: Visit = Visit.objects.filter(product_id=product_id).count()

    # ProductCategory
    product_category = Product.objects.filter(category__products=product).distinct()
    product_category_grouper = list(my_grouper(8, product_category))

    # ProductGalleryTop
    product_gallery_top = ProductGallery.objects.filter(product_id=product_id)
    product_gallery_top_grouper = list(my_grouper(3, product_gallery_top))

    # Context
    context = {
        'product': product,
        'product_gallery_top': product_gallery_top_grouper,
        'product_category_grouper': product_category_grouper,
        'category_related': category_related,
        'tag_related': tag_related,
        'new_order_form': new_order_form,
        'comment_form': comment_form,
        'page_obj': page_obj,
        'comments': comments,
        'visit_count': visit_count,
        'comments_count': comments_count,
    }

    return render(request, 'products/product_detail_page.html', context)


# FavoriteProduct
@login_required(login_url='/login')
def favorite_product(request, *args, **kwargs):
    product_id = kwargs.get('product_id')
    product = Product.objects.get_by_id(product_id)
    if product.favorite:
        product.favorite = False
        Favorites.objects.filter(product_id=product_id, user_id=request.user.id).delete()
    else:
        product.favorite = True
        Favorites.objects.create(product_id=product_id, user_id=request.user.id)
    product.save()

    return HttpResponse('')
