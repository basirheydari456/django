from django.urls import path


from .views import \
    ProductListView, product_detail_view, ProductSearchListView, ProductCategoryList, favorite_product

urlpatterns = [
    path('products/', ProductListView.as_view() , name='products'),
    path('products/<product_id>/<title>', product_detail_view , name='productDetailView'),
    path('favorite-product/<product_id>', favorite_product , name='favorite_product'),
    path('products/search', ProductSearchListView.as_view() , name='productSearchView'),
    path('products', ProductCategoryList.as_view() , name='productCategoryView'),
]