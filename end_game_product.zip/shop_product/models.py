import os

from django.db import models
from random import randint

from django.db.models import Q
from django.db.models.signals import pre_save
from django.utils.crypto import get_random_string





def upload_image_path(filepath):
    base_name = os.path.basename(filepath)
    name, ext = os.path.splitext(base_name)
    return name, ext


def upload_image_product(instance, filename):
    name, ext = upload_image_path(filename)
    new_name = randint(1, 1234567890)
    final_name = f'{new_name}{ext}'
    return f'products/{final_name}'


class ProductManager(models.Manager):
    def get_active(self):
        return self.get_queryset().filter(active=True)

    def get_by_id(self, product_id):
        qs = self.get_queryset().filter(id=product_id)
        if qs.count() == 1:
            return qs.first()
        return None

    def get_by_category(self, query):
        return self.get_queryset().filter(Q(category__name__iexact=query) | Q(category__title__iexact=query) | Q(childcategory__name__iexact=query) | Q(childcategory__title__iexact=query))

    # def get_by_child_category(self, query):
    #     return self.get_queryset().filter(Q(childcategory__name__iexact=query) | Q(childcategory__title__iexact=query))

    def search(self, query):
        lookup = Q(title__icontains=query) | Q(description__icontains=query) | Q(tag__title__icontains=query) | Q(
            tag__name__icontains=query)
        return self.get_queryset().filter(lookup, active=True).distinct()


class Color(models.Model):
    color = models.CharField(max_length=150,verbose_name='رنگ')

    class Meta:
        verbose_name_plural = 'رنگ ها'
        verbose_name = 'رنگ'


    def __str__(self):
        return self.color


class Product(models.Model):
    title = models.CharField(max_length=150, verbose_name=' عنوان فارسی')
    name = models.CharField(max_length=150, verbose_name=' عنوان انگلیسی', default='')
    color = models.ManyToManyField(Color,default='',verbose_name='رنگ',null=True,blank=True)
    # brand = models.CharField(max_length=50, verbose_name=' برند',default='')
    # categories = models.ManyToManyField()
    # color = models.CharField(max_length=6,choices=Color_Choices,default='green')
    storage = models.CharField(max_length=50, verbose_name='حافظه داخلی', default='', null=True, blank=True)
    net_work = models.CharField(max_length=50, verbose_name='شبکه های ارتباطی', default='', null=True, blank=True)
    ram = models.CharField(max_length=50, verbose_name='مقدار رم', default='', null=True, blank=True)
    system = models.CharField(max_length=50, verbose_name='سیستم عامل', default='', null=True, blank=True)
    photo_resolution = models.CharField(max_length=50, verbose_name='رزولوشن عکس', default='', null=True, blank=True)
    system_version = models.CharField(max_length=50, verbose_name='نسخه سیستم عامل', default='', null=True, blank=True)
    image = models.ImageField(upload_to=upload_image_product, null=True, blank=True,verbose_name='تصویر')
    description = models.TextField(null=True,blank=True,verbose_name='توضیحات')
    price = models.DecimalField(decimal_places=0, max_digits=20, default=00.00, null=True, blank=True,
                                verbose_name='قیمت')
    discount = models.IntegerField(default=00, verbose_name='تخفیف', null=True, blank=True)
    date = models.DateTimeField(auto_now_add=False, null=True, blank=True, verbose_name='تاریخ تخفیف')
    active = models.BooleanField(default=False, verbose_name='فعال')
    favorite = models.BooleanField(default=False, verbose_name='مورد علاقه')
    visit_count = models.IntegerField(default=0, verbose_name='تعداد بازدید')

    objects = ProductManager()

    class Meta:
        verbose_name_plural = 'محصولات'
        verbose_name = 'محصول'
        ordering = ['-id']

    def get_absolute_url(self):
        return f'/products/{self.id}/{self.title.replace(" ", "-")}'

    def get_discount_price(self):
        discount = self.discount * self.price // 100
        total_discount = self.price - discount
        return total_discount

    def __str__(self):
        return self.title


def upload_gallery_image_path(filepath):
    base_name = os.path.basename(filepath)
    name, ext = os.path.splitext(base_name)
    return name, ext


def upload_gallery_image_product(instance, filename):
    name, ext = upload_image_path(filename)
    new_name = randint(1, 1234567890)
    final_name = f'{new_name}{ext}'
    return f'products/gallery/{final_name}'


class ProductGallery(models.Model):
    image = models.ImageField(upload_to=upload_gallery_image_product, null=True, blank=True)
    slug = models.SlugField(null=True,blank=True, verbose_name='نام')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name='محصول')

    class Meta:
        verbose_name_plural = 'تصاویر'
        verbose_name = 'تصویر'

    def __str__(self):
        return self.product.title


def product_gallery_pre_save_receiver(instance,sender,*args,**kwargs):
    if not instance.slug:
        instance.slug = instance.image

pre_save.connect(product_gallery_pre_save_receiver,sender=ProductGallery)