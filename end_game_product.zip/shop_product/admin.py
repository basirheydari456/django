from django.contrib import admin

from shop_product.models import Product, ProductGallery, Color


class ProductAdminManager(admin.ModelAdmin):
    list_display = ['__str__', 'active', 'favorite', 'visit_count', 'discount']


admin.site.register(Product, ProductAdminManager)
admin.site.register(ProductGallery)
admin.site.register(Color)
