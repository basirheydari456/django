from django.apps import AppConfig

class ShopProductConfig(AppConfig):
    name = 'shop_product'
    verbose_name = 'ماژول محصولات'
